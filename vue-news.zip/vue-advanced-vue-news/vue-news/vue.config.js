module.exports = {
    lintOnSave: false // false :  eslint 기능 끔
}
