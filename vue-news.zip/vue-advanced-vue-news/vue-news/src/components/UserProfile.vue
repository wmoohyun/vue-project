<template>
  <div>
    <div class="user-container">
      <div>
        <i class="fa-solid fa-user" />
      </div>
      <div class="user-description">
        <slot name="username">
          <!-- 상위컴포넌트에서 정의할 영역 -->
        </slot>

        <div class="time">
          <slot name="time">
            <!-- 상위컴포넌트에서 정의할 영역 -->
          </slot>
          <slot name="karma">
            <!-- 상위컴포넌트에서 정의할 영역 -->
          </slot>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    info: Object
  },
  // computed: {
  //   userInfo () {
  //     return this.$store.state.user;
  //   }
  // },
}
</script>

<style scoped>
.user-container{
  display: flex; /* 수평으로 떨어지도록 */
  align-items: center;
  padding: 0.5rem;
}

.fa-user{
  font-size: 2.5rem;
}

.user-description{
  padding-left: 8px;
}

.time{
  font-size: 0.7rem;
}
</style>