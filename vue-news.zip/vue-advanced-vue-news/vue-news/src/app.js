var a = 10;
var a = 10

