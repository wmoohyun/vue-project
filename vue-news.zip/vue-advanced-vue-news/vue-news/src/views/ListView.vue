<template>
  <!-- vueinit or vuedef + tap-->
  <div>
    <list-item />
  </div>
</template>

<script>
import listItem from '../components/listItem.vue'

export default {
  components: { listItem },
    component: {
      listItem
    }
}
</script>
<style lang="">

</style>